# Project status — 11 November 2026

## Implemented in source

- Windows console Engine Probe, targeting x64 / .NET 10 / Windows build 20348+.
- Core Audio session discovery on the selected virtual ingress render endpoint.
- One Process Loopback capture per discovered PID, including its child process tree.
- Bounded per-process float ring buffers and bounded NAudio 3-compatible output providers.
- Independent PERSONAL and STREAM summing paths, channel gain/mute and master gain/mute.
- Two WASAPI shared-mode output players.
- JSON persistence for initial routing/gain/mute state.
- PowerShell build and publish scripts plus Windows GitHub Actions workflow.

## Not yet verified

- The project has not been compiled in this execution environment: no .NET SDK/compiler is installed here and outbound package restore is unavailable.
- It has not been tested with real Windows audio endpoints. A successful GitHub Actions build is the first compile gate; physical Windows playback/OBS is the next gate.
- The current design uses third-party virtual endpoints and manual Windows per-app endpoint assignment. It is not transparent system-wide routing.

## Not implemented yet

- Windows GUI and tray app.
- Android app, USB/Wi-Fi transport, pairing/authentication.
- DSP chain, microphone processing, profiles and automatic profile rules.
- Adaptive clock drift compensation, endpoint hot-plug recovery and production-grade limiter.
- A custom signed virtual audio driver.

The project must not move to the GUI milestone until the Stage 1 Windows audio test plan passes.
